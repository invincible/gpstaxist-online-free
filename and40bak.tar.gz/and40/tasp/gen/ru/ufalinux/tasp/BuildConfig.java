/** Automatically generated file. DO NOT MODIFY */
package ru.ufalinux.tasp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}