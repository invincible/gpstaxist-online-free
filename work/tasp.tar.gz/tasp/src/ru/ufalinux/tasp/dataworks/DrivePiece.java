package ru.ufalinux.tasp.dataworks;

public class DrivePiece {

	public Tariff tariff;
	public Float km=(float) 0;
	public Float min=(float) 0;
	
}
