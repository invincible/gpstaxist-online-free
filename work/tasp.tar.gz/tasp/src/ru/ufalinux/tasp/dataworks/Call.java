package ru.ufalinux.tasp.dataworks;

public class Call {
	public String name="";
	public float cost=0;
}
