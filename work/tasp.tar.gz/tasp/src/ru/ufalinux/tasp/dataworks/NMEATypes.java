package ru.ufalinux.tasp.dataworks;

public enum NMEATypes {
	GPGGA,GPGSA,GPGSV
}
