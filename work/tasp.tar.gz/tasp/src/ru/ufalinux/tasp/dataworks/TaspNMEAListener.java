package ru.ufalinux.tasp.dataworks;

//import android.location.GpsStatus.NmeaListener;
//
//public class TaspNMEAListener implements NmeaListener {
//
//	public void onNmeaReceived(long timestamp, String nmea) {
//		System.out.print(timestamp+":"+nmea);
//
//	}
//
//}
