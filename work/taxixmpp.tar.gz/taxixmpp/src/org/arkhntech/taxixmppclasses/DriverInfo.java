package org.arkhntech.taxixmppclasses;

public class DriverInfo {

	public String sign="";
	public String jid="";
	public String version="";
	public long ttl=1000;
}
