package org.arkhntech.taxixmppclasses;

public class Point {
	public float x=0;
	public float y=0;
}
